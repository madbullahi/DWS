%specify form of uptake function for adult daphnia

function consumeA = phiA(x,phiAconstant,KMA,model)

if strcmp(model,'linear')
    
consumeA=phiAconstant*x;

elseif strcmp(model,'MM')

consumeA=phiAconstant*x./(KMA+x);


elseif strcmp(model,'hill2')
    
consumeA=phiAconstant*(x.^2)./(KMA+(x.^2));  

end