%Define the differential equations

function dxdt=ddefun_2022(t,x,Z,N0,P0,D,alphaJ,alphaA,eA,eJ,deltaJ,deltaAP,deltaA,tau,KMJ,KMA,phiJterm,phiAterm)


xlag1=Z(:,1);

N=x(1);
P=x(2);
J=x(3);
A=x(4);
Ndelay=xlag1(1);
Adelay=xlag1(4);


dxdt=[
        (N0-N)*D-phiJ(N,alphaJ,KMJ,phiJterm)*J-phiA(N,alphaA,KMA,phiAterm)*A; 
        (P0-P)*D-phiJ(P,alphaJ,KMJ,phiJterm)*J-phiA(P,alphaA,KMA,phiAterm)*A;
        eA*phiA(N,alphaA,KMA,phiAterm)*A-eA*exp(-deltaJ*tau)*phiA(Ndelay,alphaA,KMA,phiAterm)*Adelay-deltaJ*(J);
        eA*exp(-deltaJ*tau)*phiA(Ndelay,alphaA,KMA,phiAterm)*Adelay-(deltaA+deltaAP*P)*(A);
];

end


