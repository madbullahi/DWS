clear

%set time interval and delay
tspan=[0 500]; lags=6;

%set parameter values
N0=100;
P0=20; 
D=0.5;
alphaJ=10;
alphaA=20;
eA=1;
eJ=1;
deltaJ=0.4; 
deltaA=0.1;  
deltaAP=10; 
tau=lags;   
KMJ=20;
KMA=20;

%choose form of uptake function
phiJterm='linear';
phiAterm='linear';

%solve equations
sol=dde23(@ddefun_2022, lags, @history_2022, tspan,[],N0,P0,D,alphaJ,alphaA,eA,eJ,deltaJ,deltaAP,deltaA,tau,KMJ,KMA,phiJterm,phiAterm);

%plot solutions
figure(1)
plot(sol.x,sol.y,'--'),hold all
legend('N','P','J','A')
figure(3)
plot(sol.x,sol.y(3,:)+sol.y(4,:),'r--'), hold all

