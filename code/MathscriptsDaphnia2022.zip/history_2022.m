% history function for t <= 0
function s = history_2022(t,x,Z,N0,P0,D,alphaJ,alphaA,eA,eJ,deltaJ,deltaAP,deltaA,tau,KMJ,KMA,phiJterm,phiAterm)

 s=[0 0 0 1];

end