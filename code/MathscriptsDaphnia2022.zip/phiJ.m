%specify form of uptake function for juvenile daphnia

function consumeJ = phiJ(x,phiJconstant,KMJ,model)

if strcmp(model,'linear')
    
consumeJ=phiJconstant*x;

elseif strcmp(model,'MM')

consumeJ=phiJconstant*x./(KMJ+x);

elseif strcmp(model,'hill2')
    
consumeJ=phiJconstant*(x.^2)./(KMJ+(x.^2));    

end